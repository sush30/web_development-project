<?php
defined('BASEPATH') OR exit('No direct scripts are allowed');

function tcpdf()
{
	require_once('tcpdf/config/lang/eng.php');
	require_once('tcpdf/tcpdf.php');
}
?>