<?php
$myfile=fopen("transaction_details.txt","r") or die("unable to open  a file");
echo fread($myfile,filesize("transaction_details.txt"));
fclose($myfile);
?>